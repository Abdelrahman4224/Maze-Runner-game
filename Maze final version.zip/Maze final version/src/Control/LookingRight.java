/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import static Control.State.gun;
import Model.Grid;
import Model.Tree;
import View.Game;

/**
 *
 * @author abdal
 */
public class LookingRight extends State{
    
    int oldI = grid.player.i;
    int oldJ = grid.player.j;

    LookingRight(Grid grid, StatusObserver gameStatusObserver) {
        super(grid, gameStatusObserver);
    }

    @Override
    public void move() {
        grid.player.right();
                        if(oldJ >= 29)
			{
				return;
			}else if(grid.isBomb(oldI, oldJ+1)) {
                            grid.player.bombHit();
                            grid.bombCrash(oldI, oldJ+1);
                            gameStatus.gameOverUpdate();
                            return;
			}else if(grid.isWall(oldI , oldJ+1)){
                            return;
                        }else if(grid.isTree(oldI, oldJ+1)){
                            return;
                        }else if(grid.isGasBomb(oldI, oldJ+1)){
                            grid.player.gasbombHit();
                            grid.gasBombCrash(oldI, oldJ+1);
                            checkStamina();
                            return;
                        }else if(grid.isReloadGift(oldI, oldJ+1))
                        {
                            gun.reload();
                            Game.updateBullets();
                            grid.takeGift(oldI, oldJ+1);
                        }else if(grid.isHealthGift(oldI, oldJ+1))
                        {
                            grid.player.increaseStamina();
                            Game.updateStamina();
                            grid.takeGift(oldI, oldJ+1);
                        }
                        
                        grid.player.j = oldJ+1;
                        
                         if(grid.isEnd(oldI, oldJ+1))
                            gameStatus.winUpdate();
    }

    
@Override
public void shoot() {
    if(gun.shoot())
    {
        Game.updateBullets();
        for(int j=oldJ+1; j<=29; j++)
        {
            if(grid.isTree(oldI, j))
            {
                grid.treeSmash(oldI, j);
                Game.updateScore(10);
                break;
            }else if(grid.isBomb(oldI, j)){
                grid.bombCrash(oldI, j);
                Game.updateScore(20);
                break;
            }else if(grid.isGasBomb(oldI, j)){
                grid.gasBombCrash(oldI, j);
                Game.updateScore(15);
                break;
            }else if(grid.isWall(oldI, j))
                break;
                
        }
    }else System.out.print("gun is empty, please reload\n");
        
}
    
    
    
}
