/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Bomb;
import Model.Bullet;
import Model.Explode;
import Model.Grid;
import Model.Tree;
import View.Game;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abdal
 */
public class LookingUp extends State{
    
    int oldI = grid.player.i;
    int oldJ = grid.player.j;

    public LookingUp(Grid grid, StatusObserver gameStatus) {
        super(grid, gameStatus);
    }
    
    @Override
    public void move(){
        
        grid.player.up();
        
        if(oldI <= 0)
            {
		return;
            }else if(grid.isBomb(oldI-1, oldJ)) {
                grid.player.bombHit();
                grid.bombCrash(oldI-1, oldJ);
                gameStatus.gameOverUpdate();
                return;
            }else if(grid.isWall(oldI-1 , oldJ)){
                return;
            }else if(grid.isTree(oldI-1, oldJ)){
                return;
            }else if(grid.isGasBomb(oldI-1, oldJ)){
                    grid.player.gasbombHit();
                    grid.gasBombCrash(oldI-1, oldJ);
                    checkStamina();
                    return;
            }else if(grid.isReloadGift(oldI-1, oldJ))
            {
                gun.reload();
                Game.updateBullets();
                grid.takeGift(oldI-1, oldJ);
            }else if(grid.isHealthGift(oldI-1, oldJ))
            {
                grid.player.increaseStamina();
                Game.updateStamina();
                checkStamina();
                grid.takeGift(oldI-1, oldJ);
            }
        
            grid.player.i = oldI-1;
            
            if(grid.isEnd(oldI-1, oldJ))
                gameStatus.winUpdate();
    }
Bullet bullet = new Bullet();
@Override
public void shoot() {
    if(gun.shoot())
    {
        Game.updateBullets();
        for(int i=oldI-1; i>=0; i--)
        {
            if(grid.isTree(i, oldJ))
            {
                grid.treeSmash(i, oldJ);
                Game.updateScore(10);
                break;
            }else if(grid.isBomb(i, oldJ)){
                grid.bombCrash(i, oldJ);
                Game.updateScore(20);
                break;
            }else if(grid.isGasBomb(i, oldJ)){
                grid.gasBombCrash(i, oldJ);
                Game.updateScore(15);
                break;
            }else if(grid.isWall(i, oldJ))
                break;
                
        }
    }else System.out.print("gun is empty, please reload\n");
        
}

public void shootUpEffect(int x1, int y1, int x2) throws InterruptedException
{
    for(int i=x1; i<x2; i--)
    {
        grid.shapesongrid[i][y1] = bullet;
    }
    Thread.sleep(200);
    for(int i=x1; i<x2; i--)
    {
        grid.shapesongrid[i][y1] = null;
    }
}
    
    
    
}
