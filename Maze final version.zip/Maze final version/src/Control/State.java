
package Control;

import Model.Grid;
import Model.Gun;
import Model.Player;

/**
 *
 * @author abdal
 */
public abstract class State {
    
    public Grid grid;
    public StatusObserver gameStatus;
    public static Gun gun = new Gun();

    public State(Grid grid, StatusObserver gameStatus) {
        this.grid = grid;
        this.gameStatus = gameStatus;
    }
    
    public void move(){
    
    }
        
    public void shoot(){
        
    }
    
    public void checkStamina(){
            if(grid.player.getStamina()==0)
                gameStatus.gameOverUpdate();
            /*if(grid.player.getStamina()==1)
                grid.player = new UnarmoredPlayer(grid.player.i, grid.player.j);
            if(grid.player.getStamina()==2)
                grid.player = new Player(grid.player.i, grid.player.j);*/
        }
}
