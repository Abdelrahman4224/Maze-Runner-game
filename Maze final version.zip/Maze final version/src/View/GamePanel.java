package View;

import Model.Bomb;
import Model.BrickWall;
import Model.Door;
import Model.GasBomb;
import Model.Grid;
import Model.HealthGift;
import Model.ReloadGift;
import Model.Tree;
import java.awt.Graphics;
import javax.swing.JPanel;


public class GamePanel extends JPanel {
    
    public Grid currentgrid;
	
    public GamePanel(){
        currentgrid = Grid.getGrid(new BrickWall(), new Bomb(), new Tree(), new GasBomb(), new Door());
    }
    
    @Override
    public void paintComponent(Graphics g){
    	
    	super.paintComponent(g);
        currentgrid.drawGrid(g);
    }

    public Grid getCurrentgrid() {
        return currentgrid;
    }
    
    
    
}
