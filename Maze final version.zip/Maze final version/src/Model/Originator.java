/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author abdal
 */
public class Originator {
    
    public Grid game;

    public void setGrid(Grid game) {
        this.game = game;
    }

    public Memento storeData(){
        return new Memento(game);
    }
    
    public Grid restoreData(Memento memento){ 
       return game = memento.getSavedGame();
    }
}
