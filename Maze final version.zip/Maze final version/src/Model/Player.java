/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.Game;

/**
 *
 * @author mabady
 */
public class Player extends Sprite {
    public int i,j;
    private static int stamina = 2;
    
    public Player(int i , int j) {
        super("src/Model/Images/right.png");
        this.i = i;
        this.j = j;
    }
    
    public void right(){
        super.changeImage("src/Model/Images/right.png");
    }
    
    public void left(){
        super.changeImage("src/Model/Images/left.png");
    }
    
    public void up(){
        super.changeImage("src/Model/Images/up.png");
    }
    
    public void down(){
        super.changeImage("src/Model/Images/down.png");
    }

    public static int getStamina() {
        return stamina;
    }

    public void gasbombHit(){
        stamina--;
    }
    
    public void bombHit(){
        stamina -= 2;
    }
    
    public void increaseStamina(){
        stamina = 2;
    }

    
    
}
