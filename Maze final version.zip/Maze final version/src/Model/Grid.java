/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import View.Game;
import java.awt.Graphics;


public class Grid {
    
    public Sprite [][] shapesongrid;
    public BrickWall wall;
    public Tree tree;
    public Bomb bomb;
    public GasBomb gasbomb;
    public Gift reloadGift;
    public Gift healthGift;
    public GiftFactory GF = new GiftFactory();
    int dimensions;
    public Player player;
    public Door end;
    
    static Grid grid=null;
    public static Grid getGrid(BrickWall wall, Bomb bomb, Tree tree, GasBomb gasbomb, Door end){
        if(grid==null)
            grid = new Grid(wall, bomb, tree, gasbomb, end);
        return grid;
    }
    
    private Grid(BrickWall wall, Bomb bomb, Tree tree, GasBomb gasbomb, Door end) {
        this.wall  = wall;
        this.tree = tree;
        this.bomb = bomb;
        this.gasbomb = gasbomb;
        this.reloadGift = reloadGift;
        this.healthGift = healthGift;
        this.end = end;
        dimensions = 30;
        shapesongrid = new Sprite[dimensions][dimensions];
        
        
        for(int i = 0; i < dimensions;i++){
            for(int j =0;j < dimensions;j++){
                double randomnumber = Math.random();
                //System.out.println("random number" + randomnumber);
                if(randomnumber>0.7)
                    {
                        if(randomnumber>0.85)
                            shapesongrid[i][j]= tree;
                        else shapesongrid[i][j]= wall;
                    }
                else if(randomnumber > 0.6 && randomnumber<0.7)
                {
                    if(randomnumber>0.65)
                        shapesongrid[i][j]= (Sprite) gasbomb;
                    else shapesongrid[i][j] = (Sprite) bomb;
                }else if(randomnumber < 0.05)
                {
                    if(randomnumber > 0.025)
                        shapesongrid[i][j]= GF.getGift("ReloadGift");
                    else shapesongrid[i][j]= GF.getGift("HealthGift");
                }
            }
        }
        int i = dimensions-1;
        for (int j = 0; j < dimensions; j++) {
            if(shapesongrid[i][j]== null){
                player = new Player(i,j);
             break;
            }
        }
        i = 0;
        for (int j = dimensions-1; j > 0; j--) {
            if(shapesongrid[i][j]== null){
                shapesongrid[i][j]= end;
             break;
            }
        }
       
    }
     public void drawGrid(Graphics g){
            for(int i = 0; i<dimensions;i++){
            for(int j =0;j<dimensions;j++){
              if(shapesongrid[i][j]!= null){
                  
                  g.drawImage(shapesongrid[i][j].image,j*600/dimensions , i*600/dimensions,600/30,600/30, null);
                  
              }
                }
            }
            int i = player.i;
            int j = player.j;
             g.drawImage(player.image,j*600/30 , i*600/30,600/30,600/30, null);
        }

     public Boolean isBomb(int i, int j)
     {
    	 return shapesongrid[i][j] instanceof Bomb;
     }
     
     public Boolean isWall(int i, int j)
     {
         return shapesongrid[i][j] instanceof BrickWall;
     }
     
     public Boolean isTree(int i, int j)
     {
         return shapesongrid[i][j] instanceof Tree;
     }
     
     public Boolean isGasBomb(int i, int j)
     {
         return shapesongrid[i][j] instanceof GasBomb;
     }
     
     public boolean isReloadGift(int i, int j)
     {
         return shapesongrid[i][j] instanceof ReloadGift;
     }
     
     public boolean isHealthGift(int i, int j)
     {
         return shapesongrid[i][j] instanceof HealthGift;
     }
     
     public boolean isEnd(int i, int j)
     {
         return shapesongrid[i][j] instanceof Door;
     }
     
     public void bombCrash(int i, int j)
     {
        shapesongrid[i][j] = new Explode("src/Model/Images/bomb_explode.png");
        Game.updateStamina();
     }
     
     public void gasBombCrash(int i, int j)
     {
        shapesongrid[i][j] = new Explode("src/Model/Images/gasbomb_explode.png"); 
        Game.updateStamina();
     }
     
     public void treeSmash(int i, int j)
     {
         shapesongrid[i][j] = new Explode("src/Model/Images/smashed_tree.jpg");
     }
    
     public void takeGift(int i, int j)
     {
         shapesongrid[i][j] = null;
     }
     
     
}
