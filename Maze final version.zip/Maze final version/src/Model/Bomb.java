package Model;

public class Bomb extends Sprite{

    public Bomb() {	
	super("src/Model/Images/bomb.png");
    }
    
}
